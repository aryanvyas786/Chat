import { loadPdfDocs } from "./loaders/pdfLoader";
import { splitDocs } from "./utils/splitters";
import { createFaissStore } from "./vectorsstore/faissStore";

const run = async () => {
  const rawDocs = await loadPdfDocs("data/sample.pdf");
  const chunks = await splitDocs(rawDocs);
  const vectorStore = await createFaissStore(chunks);

  const results = await vectorStore.similaritySearch(
    "What is the revenue of the company in 2023?",
    1
  );

  console.log("🔍 Top Match:\n", results[0].pageContent);
};

run();
