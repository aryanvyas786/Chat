import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";

export const splitDocs = async (docs: any[]) => {
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 1000,
    chunkOverlap: 200,
  });

  const splits = await splitter.splitDocuments(docs);
  return splits;
};
