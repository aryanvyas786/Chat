import { PDFLoader } from "@langchain/community/document_loaders/fs/pdf";
import path from 'path';

// Function to get __dirname in ESM
const __dirname = path.dirname(new URL(import.meta.url).pathname);

export const loadPdfDocs = async (filePath: string) => {
  const loader = new PDFLoader(filePath);
  const docs = await loader.load();
  return docs;
};

const run = async () => {
  const filePath = path.resolve(__dirname, 'data', 'sample.pdf');
  const rawDocs = await loadPdfDocs(filePath);

  console.log("Loaded Docs:", rawDocs);
};

run();
