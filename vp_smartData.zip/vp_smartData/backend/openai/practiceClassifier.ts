import { OpenAI } from "openai";
import { ChatCompletionMessageParam } from "openai/resources/chat/completions";
import Pratice from "../models/pratice";
import dotenv from "dotenv";

dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

const apiKey = process.env.OPENAI_API_KEY;

if (!apiKey) {
  throw new Error(
    "Missing OpenAI API key. Set OPENAI_API_KEY in environment variables."
  );
}

const openai = new OpenAI({ apiKey });

export const classifyPractice = async (jobPost: string): Promise<string> => {
  try {
    console.log("Fetching active practices...");

    const practices = await Pratice.findAll({
      attributes: ["practice_id", "practice_name"],
    });

    const practicesFormatted = JSON.stringify(practices, null, 2);

    const systemPrompt = `
You are an AI solution architect with 10 years of experience in building AI-enabled software applications. Your job is to analyze job post content and return the most appropriate practice category from the list below.

\`\`\`${practicesFormatted}\`\`\`

Output format:
{
  "practice_id": [write practice id],
  "practice_name": [write practice name]
}
`;

    const messages: ChatCompletionMessageParam[] = [
      { role: "system", content: systemPrompt },
      { role: "user", content: jobPost },
    ];

    console.log("Sending request to OpenAI with job post...");
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages,
    });

    const result = response.choices[0].message.content || "";
    console.log("OpenAI response received.");
    return result;
  } catch (error) {
    console.error("Error in classifyPractice:", error);
    throw new Error("Failed to classify job post.");
  }
};
