import { Router } from 'express';
import { getLatestReports } from '../controllers/salesReportController';

const salesRouter = Router();

salesRouter.get('/auth/sales/reports/latest', getLatestReports);

export default salesRouter;
