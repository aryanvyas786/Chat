// import { Router, Request, Response } from "express";
// import { verifyToken } from "../middleware/verifyToken";
// import upload from "../middleware/multer";
// import { adminRegister,adminLogin } from "../controllers/adminControllers";

// const adminRouter = Router();

// adminRouter.post("/auth/adminRegister", adminRegister);
// adminRouter.post("/auth/adminLogin", adminLogin);
// export default adminRouter;