import { Request, Response } from 'express';
import { classifyPractice } from '../openai/practiceClassifier';
import { StatusCodes } from "../utils/statusCodes";

export const classifyPracticeController = async (req: Request, res: Response): Promise<void> => {
  try {
    console.log("Incoming classifyPractice request body:", req.body);

    const { jobPost } = req.body;

    if (!jobPost) {
      res.status(StatusCodes.BAD_REQUEST).json({
        status: "BAD_REQUEST",
        message: "Missing required field: jobPost",
      });
      return;
    }

    const result = await classifyPractice(jobPost);

    res.status(StatusCodes.OK).json({
      status: "SUCCESS",
      data: result,
    });
    return;

  } catch (error) {
    console.error("Error in classifyPracticeController:", error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      status: "INTERNAL_SERVER_ERROR",
      message: "An error occurred while classifying the job post.",
    });
    return;
  }
};

