import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';
  class SalesClouserReport extends Model {
    id!: number;
    prospect_id!: number;
    lead_id!: number;
    lead_type!: number;
    userID!: string;
    type_Id!: number;
    pitch_type!: number;
    practice_id!: number;
    practice_category!: number;
    project_id!: number;
    channel_id!: number;
    technology_id!: number;
    domain_id!: number;
    directTypeId!: number;
    portal_url!: string;
    hours!: number;
    rate!: number;
    bookingamount!: number;
    consultant_bookingamount!: number;
    frontender!: number;
    backender!: number;
    backender_percent!: number;
    opener!: number;
    closer!: number;
    repeatStatus!: string;
    newClosure!: string;
    territoryId!: number;
    clientEmail!: string;
    clientName!: string;
    client_contact!: string;
    comment!: string;
    prospect_comment!: string;
    prospect_original_requirement!: string;
    skillset!: string;
    understanding!: string;
    assigned_by!: number;
    report_type!: string;
    closure_type!: string;
    extension_type!: string;
    no_of_recources!: number;
    date!: Date;
    salesperson_id!: number;
    rpt_salesperson!: number;
    addedDate!: Date;
    backender_assigned_date!: string;
    bkoDone!: number;
    closureStatus!: number;
    sub_practice_id!: number;
    unique_id!: string;
    portal_title!: string;
    extension_reason!: string;
    used_framework!: string;
    pre_award!: string;
    team_closure!: string;
    sales_remove_comment!: string;
    approval_date!: string;
    approved_by!: number;
    client_approval!: number;
    lead_status!: number;
    lead_updated_by!: number;
    is_closure_exception!: number;
    add_followup_status!: number;
    add_followup_status_updated_by!: number;
    exce_added_by!: number;
    BCGMember?: string;
    stateId!: number;
    countryId!: number;
    city!: string;
    delivery_model!: string;
    asset_type!: string;
    psm!: number;
    psm_details!: string;
    teamBuddy!: number;
    buddy_percentage!: number;
    doc_file?: string;
    repeat_mapped_projectId!: number;
    PMB_link!: string;
    comment_date!: Date;
    selected_domain?: number;
    selected_sub_domain?: number;
    selected_domain_category?: number;
    estimation_price?: number;
    price_type?: string;
    complexity_type?: string;
  
  }

  SalesClouserReport.init(
    {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    prospect_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    },
    lead_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: "will refer as a reference of lead_assignment table"
    },
    lead_type: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    userID: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    type_Id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    pitch_type: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    practice_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    practice_category: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    project_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    channel_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    technology_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    domain_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    directTypeId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    portal_url: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    hours: {
      type: DataTypes.FLOAT(10,2),
      allowNull: false
    },
    rate: {
      type: DataTypes.DOUBLE(10,2),
      allowNull: false
    },
    bookingamount: {
      type: DataTypes.DOUBLE(10,2),
      allowNull: false
    },
    consultant_bookingamount: {
      type: DataTypes.DOUBLE(10,2),
      allowNull: false
    },
    frontender: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    backender: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    backender_percent: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    opener: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    closer: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    repeatStatus: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    newClosure: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    territoryId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    clientEmail: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    clientName: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    client_contact: {
      type: DataTypes.STRING(15),
      allowNull: false
    },
    comment: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    prospect_comment: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    prospect_original_requirement: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    skillset: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    understanding: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    assigned_by: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    report_type: {
      type: DataTypes.STRING(30),
      allowNull: false
    },
    closure_type: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    extension_type: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    no_of_recources: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    date: {
      type: DataTypes.DATE,
      allowNull: false
    },
    salesperson_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    rpt_salesperson: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    },
    addedDate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
    },
    backender_assigned_date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    bkoDone: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    closureStatus: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: "1=>Active,0=>De-active"
    },
    sub_practice_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    },
    unique_id: {
      type: DataTypes.STRING(200),
      allowNull: false
    },
    portal_title: {
      type: DataTypes.STRING(200),
      allowNull: false
    },
    extension_reason: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    used_framework: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    pre_award: {
      type: DataTypes.STRING(20),
      allowNull: false,
      comment: "Yes\/NO\/Yes, but Provisional"
    },
    team_closure: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    sales_remove_comment: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    approval_date: {
      type: DataTypes.DATEONLY,
      allowNull: false
    },
    approved_by: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    client_approval: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    lead_status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: "1=>active,0=>deactive,2=>drop"
    },
    lead_updated_by: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    is_closure_exception: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0,
      comment: "0=>not in exception,1=>exception"
    },
    add_followup_status: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    add_followup_status_updated_by: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    exce_added_by: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    BCGMember: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    stateId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    countryId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    city: {
      type: DataTypes.STRING(150),
      allowNull: false
    },
    delivery_model: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    asset_type: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    psm: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    psm_details: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    teamBuddy: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    buddy_percentage: {
      type: DataTypes.TINYINT,
      allowNull: false
    },
    doc_file: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    repeat_mapped_projectId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    PMB_link: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    comment_date: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP')
    },
    selected_domain: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    selected_sub_domain: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    selected_domain_category: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    estimation_price: {
      type: DataTypes.DOUBLE(10,2),
      allowNull: true
    },
    price_type: {
      type: DataTypes.STRING(5),
      allowNull: true
    },
    complexity_type: {
      type: DataTypes.STRING(5),
      allowNull: true
    },
  },
   {
    sequelize,
    tableName: 'SalesClouserReport',
    timestamps: false
  }
)

export default SalesClouserReport;