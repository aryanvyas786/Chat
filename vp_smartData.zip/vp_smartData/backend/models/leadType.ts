import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class LeadType extends Model {
  id!: number;
  name!: string;
  status!: number;
}
LeadType.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    status: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
      comment: "0=>deactive,1 active"
    }
  }, {
    sequelize,
    tableName: 'lead_type',
    timestamps: false
  });

  export default LeadType;