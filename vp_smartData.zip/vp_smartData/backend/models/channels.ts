import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Channels extends Model {
  ChannelId!: number;
  ChannelName!: string;
  fld_shortcode!: string;
  status!: number;
}

Channels.init({
    ChannelId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    ChannelName: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    fld_shortcode: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    }
  }, {
    sequelize,
    tableName: 'Channels',
    timestamps: false
  });

export default Channels;