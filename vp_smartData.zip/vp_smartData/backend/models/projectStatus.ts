import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class ProjectStatus extends Model{
  id!: number;
  projectStatus!: string;
  pCode!: string;
  statusOrder!: number;
  status!: number;
}
ProjectStatus.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    projectStatus: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    pCode: {
      type: DataTypes.STRING(5),
      allowNull: false
    },
    statusOrder: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    }
  }, {
    sequelize,
    tableName: 'ProjectStatus',
    timestamps: false
  });

  export default ProjectStatus;
