import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class BusiUnit extends Model {
  fld_busiUnitId!: number;
  fld_busiUnit!: string;
  fld_shortcode!: string;
  isRevenueGroup?: number;
  fld_issales!: number;
  is_resourcegroup!: number;
  is_enggGroup!: number;
  group_id!: string;
  is_closure!: number;
  is_hc!: number;
  hc_order!: number;
  status!: number;
}

BusiUnit.init({
    fld_busiUnitId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    fld_busiUnit: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    fld_shortcode: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    isRevenueGroup: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    fld_issales: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    is_resourcegroup: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    is_enggGroup: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    group_id: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    is_closure: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    is_hc: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    hc_order: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    status: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: 1,
      comment: "1=>Active,0=>Deactive"
    }
  }, {
    sequelize,
    tableName: 'BusiUnit',
    timestamps: false
  }
);

export default BusiUnit;