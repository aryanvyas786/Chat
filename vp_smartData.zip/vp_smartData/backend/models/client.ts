import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Client extends Model  {
  id!: number;
  clientName!: string;
  corporateName!: string;
  clientEmail!: string;
  clientContactNumber!: string;
  clientAddress!: string;
  billing_name?: string;
  billing_email?: string;
  billing_email_cc?: string;
  billing_address?: string;
  postal_code!: number;
  city!: string;
  contactIMO!: string;
  fld_empCorState!: string;
  countryId!: string;
  comment!: string;
}
Client.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    clientName: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    corporateName: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    clientEmail: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    clientContactNumber: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    clientAddress: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    billing_name: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    billing_email: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    billing_email_cc: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    billing_address: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    postal_code: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    city: {
      type: DataTypes.STRING(30),
      allowNull: false
    },
    contactIMO: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    fld_empCorState: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    countryId: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    comment: {
      type: DataTypes.TEXT,
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'client',
    timestamps: false
  });

  export default Client;
