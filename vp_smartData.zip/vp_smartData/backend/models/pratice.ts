import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Pratice extends Model {
  practice_id!: number;
  parent_id!: number;
  practice_name!: string;
  practice_code!: string;
  practice_comment!: string;
  status!: number;
  new_status!: number;
}

Pratice.init({
    practice_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    parent_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    practice_name: {
      type: DataTypes.STRING(150),
      allowNull: false
    },
    practice_code: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    practice_comment: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    },
    new_status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    }
  }, {
    sequelize,
    tableName: 'Pratice',
    timestamps: false
  }
);
export default Pratice;